package com.jodo.android;

public class CaptureAct {
}
